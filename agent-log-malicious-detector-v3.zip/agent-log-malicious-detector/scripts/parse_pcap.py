#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pure-Python parser for pcap/pcapng network capture files.

No external dependency (scapy/tshark) is required. Supports:
  * Classic libpcap format (magic 0xa1b2c3d4 / byte-swapped).
  * pcapng format (Section Header / Interface Description / Enhanced /
    Simple Packet blocks) with byte-order detection.

Parses Ethernet -> IPv4/IPv6 -> TCP/UDP headers to extract flow tuples
(src/dst IP, ports, protocol, bytes). Aggregates packet data into flows
and produces a text corpus for the rule scorer.
"""

from __future__ import annotations

import socket
import struct
from collections import defaultdict
from pathlib import Path


# Link types we know how to decode.
LINKTYPE_ETHERNET = 1
LINKTYPE_RAW = 101
LINKTYPE_LINUX_SLL = 113
LINKTYPE_NULL = 0


def _ip_str(raw: bytes) -> str:
    return socket.inet_ntop(socket.AF_INET, raw) if len(raw) == 4 else socket.inet_ntop(socket.AF_INET6, raw)


def _decode_l3(pkt: bytes, offset: int) -> dict | None:
    """Decode the IP layer starting at ``offset``. Returns flow info dict."""
    if offset >= len(pkt):
        return None
    version = (pkt[offset] >> 4) & 0xF
    if version == 4:
        if offset + 20 > len(pkt):
            return None
        ihl = (pkt[offset] & 0x0F) * 4
        total_len = struct.unpack_from("!H", pkt, offset + 2)[0]
        proto = pkt[offset + 9]
        src_ip = _ip_str(pkt[offset + 12:offset + 16])
        dst_ip = _ip_str(pkt[offset + 16:offset + 20])
        l4_off = offset + ihl
        return _decode_l4(pkt, l4_off, proto, src_ip, dst_ip, total_len)
    if version == 6:
        if offset + 40 > len(pkt):
            return None
        payload_len = struct.unpack_from("!H", pkt, offset + 4)[0]
        proto = pkt[offset + 6]
        src_ip = _ip_str(pkt[offset + 8:offset + 24])
        dst_ip = _ip_str(pkt[offset + 24:offset + 40])
        l4_off = offset + 40
        return _decode_l4(pkt, l4_off, proto, src_ip, dst_ip, payload_len + 40)
    return None


def _decode_l4(pkt: bytes, off: int, proto: int, src_ip: str, dst_ip: str, ip_len: int) -> dict | None:
    if proto == 6 and off + 20 <= len(pkt):  # TCP
        src_port, dst_port = struct.unpack_from("!HH", pkt, off)
        data_off = ((pkt[off + 12] >> 4) & 0xF) * 4
        payload_off = off + data_off
        payload_len = max(0, ip_len - (payload_off - off))
        return {
            "src_ip": src_ip, "dst_ip": dst_ip,
            "src_port": src_port, "dst_port": dst_port,
            "proto": "TCP", "payload_len": payload_len,
            "payload_preview": pkt[payload_off:payload_off + 64],
        }
    if proto == 17 and off + 8 <= len(pkt):  # UDP
        src_port, dst_port, udp_len = struct.unpack_from("!HHH", pkt, off)
        payload_off = off + 8
        payload_len = max(0, udp_len - 8)
        return {
            "src_ip": src_ip, "dst_ip": dst_ip,
            "src_port": src_port, "dst_port": dst_port,
            "proto": "UDP", "payload_len": payload_len,
            "payload_preview": pkt[payload_off:payload_off + 64],
        }
    if proto == 1:
        return {"src_ip": src_ip, "dst_ip": dst_ip, "src_port": 0, "dst_port": 0,
                "proto": "ICMP", "payload_len": 0, "payload_preview": b""}
    return {"src_ip": src_ip, "dst_ip": dst_ip, "src_port": 0, "dst_port": 0,
            "proto": str(proto), "payload_len": 0, "payload_preview": b""}


def _decode_l2(pkt: bytes, linktype: int) -> dict | None:
    """Strip the link-layer header and decode the IP layer."""
    if linktype == LINKTYPE_ETHERNET:
        if len(pkt) < 14:
            return None
        ethertype = struct.unpack_from("!H", pkt, 12)[0]
        if ethertype == 0x0800 or ethertype == 0x86DD:
            return _decode_l3(pkt, 14)
        return None
    if linktype == LINKTYPE_RAW:
        return _decode_l3(pkt, 0)
    if linktype == LINKTYPE_NULL:
        if len(pkt) < 4:
            return None
        fam = struct.unpack_from("<I", pkt, 0)[0]
        if fam in (2, 24, 28, 30):
            return _decode_l3(pkt, 4)
        return None
    if linktype == LINKTYPE_LINUX_SLL:
        if len(pkt) < 16:
            return None
        return _decode_l3(pkt, 16)
    return None


def _parse_classic_pcap(data: bytes) -> tuple[list[tuple[int, bytes]], int]:
    """Parse classic pcap. Returns (list of (ts, packet_bytes), linktype)."""
    if len(data) < 24:
        return [], 0
    magic = data[:4]
    if magic == b"\xd4\xc3\xb2\xa1":
        endian = "<"
    elif magic == b"\xa1\xb2\xc3\xd4":
        endian = ">"
    elif magic in (b"\x4d\x3c\xb2\xa1", b"\xa1\xb2\x3c\x4d"):
        # Nanosecond-resolution variants.
        endian = "<" if magic == b"\x4d\x3c\xb2\xa1" else ">"
    else:
        return [], 0
    _, _, _, _, _, _, network = struct.unpack_from(f"{endian}IHHIIII", data, 0)
    off = 24
    packets: list[tuple[int, bytes]] = []
    while off + 16 <= len(data):
        ts_sec, ts_usec, incl_len, _orig_len = struct.unpack_from(f"{endian}IIII", data, off)
        off += 16
        if off + incl_len > len(data):
            break
        packets.append((ts_sec, data[off:off + incl_len]))
        off += incl_len
    return packets, network


def _parse_pcapng(data: bytes) -> list[tuple[int, bytes]]:
    """Parse pcapng. Returns list of (ts, packet_bytes) using first interface's linktype via flows."""
    packets: list[tuple[int, bytes]] = []
    off = 0
    endian = "<"
    linktypes: list[int] = [LINKTYPE_ETHERNET]
    if_shb_seen = False
    while off + 12 <= len(data):
        block_type, block_total_len = struct.unpack_from(f"{endian}II", data, off)
        if not if_shb_seen and block_type == 0x0A0D0D0A:
            # Section Header Block - detect byte order from body magic.
            body = data[off + 8:off + block_total_len - 4]
            if len(body) >= 4:
                bom = body[:4]
                if bom == b"\x1a\x2b\x3c\x4d":
                    endian = ">"
                elif bom == b"\x4d\x3c\x2b\x1a":
                    endian = "<"
                # Re-read block_total_len with correct endian.
                block_type, block_total_len = struct.unpack_from(f"{endian}II", data, off)
            if_shb_seen = True
        if block_total_len < 12 or off + block_total_len > len(data):
            break
        body = data[off + 8:off + block_total_len - 4]
        if block_type == 0x00000001 and len(body) >= 4:  # IDB
            linktype = struct.unpack_from(f"{endian}H", body, 0)[0]
            linktypes.append(linktype)
        elif block_type == 0x00000006 and len(body) >= 20:  # EPB
            _iface, ts_hi, ts_lo, cap_len, _pkt_len = struct.unpack_from(f"{endian}IIIII", body, 0)
            pkt_off = 20
            # Packet data is padded to 4 bytes.
            padded = (cap_len + 3) & ~3
            if pkt_off + padded <= len(body):
                ts = (ts_hi << 32) | ts_lo
                packets.append((ts, body[pkt_off:pkt_off + cap_len]))
        elif block_type == 0x00000003 and len(body) >= 4:  # SPB
            pkt_len = struct.unpack_from(f"{endian}I", body, 0)[0]
            pkt_off = 4
            padded = (pkt_len + 3) & ~3
            if pkt_off + padded <= len(body):
                packets.append((0, body[pkt_off:pkt_off + pkt_len]))
        off += block_total_len
    # Stash linktype on a sentinel via attribute-free approach: we use first IDB linktype.
    # Attach linktype by encoding into packets list via module-level stash.
    _PCAPNG_LINKTYPE[0] = linktypes[1] if len(linktypes) > 1 else LINKTYPE_ETHERNET
    return packets


_PCAPNG_LINKTYPE = [LINKTYPE_ETHERNET]


def parse_pcap(path: Path) -> dict:
    """Parse a pcap/pcapng file and return aggregated flows + summary.

    Returns:
        flows        - list of {src_ip, dst_ip, src_port, dst_port, proto,
                              packets, bytes, payload_preview_hex}
        all_text     - flat text corpus for rule scoring
        total_packets- int
        total_bytes  - int
        external_ips - sorted unique dst IPs (non-private heuristic)
        parse_error  - str (empty if ok)
    """
    with open(path, "rb") as fh:
        data = fh.read()
    if not data:
        return _empty_pcap_result("empty_file")
    magic = data[:4]
    linktype = LINKTYPE_ETHERNET
    packets: list[tuple[int, bytes]] = []
    if magic == b"\x0a\x0d\x0d\x0a":
        packets = _parse_pcapng(data)
        linktype = _PCAPNG_LINKTYPE[0]
    else:
        packets, linktype = _parse_classic_pcap(data)
        if not packets and not magic.startswith(b"\xd4") and not magic.startswith(b"\xa1"):
            return _empty_pcap_result("unknown_format")

    flows: dict[tuple, dict] = {}
    total_bytes = 0
    for _ts, pkt in packets:
        info = _decode_l2(pkt, linktype)
        if not info:
            continue
        total_bytes += info["payload_len"]
        key = (info["src_ip"], info["dst_ip"], info["src_port"], info["dst_port"], info["proto"])
        f = flows.setdefault(key, {
            "src_ip": info["src_ip"], "dst_ip": info["dst_ip"],
            "src_port": info["src_port"], "dst_port": info["dst_port"],
            "proto": info["proto"], "packets": 0, "bytes": 0,
            "payload_preview_hex": "",
        })
        f["packets"] += 1
        f["bytes"] += info["payload_len"]
        if not f["payload_preview_hex"] and info["payload_preview"]:
            f["payload_preview_hex"] = info["payload_preview"].hex()[:128]

    flow_list = list(flows.values())
    flow_list.sort(key=lambda x: x["bytes"], reverse=True)
    external_ips = sorted({f["dst_ip"] for f in flow_list if _looks_external(f["dst_ip"])})

    text_parts = []
    for f in flow_list[:200]:
        text_parts.append(
            f"[{f['proto']}] {f['src_ip']}:{f['src_port']} -> "
            f"{f['dst_ip']}:{f['dst_port']} pkts={f['packets']} bytes={f['bytes']}"
        )
    return {
        "flows": flow_list,
        "all_text": "\n".join(text_parts),
        "total_packets": len(packets),
        "total_bytes": total_bytes,
        "external_ips": external_ips,
        "parse_error": "",
    }


def _looks_external(ip: str) -> bool:
    """Heuristic: is the IP non-loopback / non-link-local / non-private?"""
    try:
        import ipaddress
        addr = ipaddress.ip_address(ip)
        return not (addr.is_loopback or addr.is_private or addr.is_link_local or addr.is_multicast or addr.is_unspecified)
    except ValueError:
        return False


def _empty_pcap_result(err: str) -> dict:
    return {
        "flows": [],
        "all_text": "",
        "total_packets": 0,
        "total_bytes": 0,
        "external_ips": [],
        "parse_error": err,
    }
