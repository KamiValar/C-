#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared utilities for the agent-log-malicious-detector skill.

Provides MD5 hashing, safe tar extraction, encoding-tolerant text reading,
JSONL parsing, and text truncation helpers used across all parsers.
"""

from __future__ import annotations

import hashlib
import json
import tempfile
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class TarRecord:
    """Holds everything extracted/analysed for a single tar package."""

    tar_path: Path
    tar_md5: str = ""
    extract_dir: Path | None = None
    session_events: list[dict] = field(default_factory=list)
    session_all_text: str = ""
    session_summary: dict = field(default_factory=dict)
    syslog_lines: list[str] = field(default_factory=list)
    syslog_all_text: str = ""
    syslog_summary: dict = field(default_factory=dict)
    sysmon_events: list[dict] = field(default_factory=list)
    sysmon_all_text: str = ""
    sysmon_summary: dict = field(default_factory=dict)
    pcap_flows: list[dict] = field(default_factory=list)
    pcap_all_text: str = ""
    pcap_summary: dict = field(default_factory=dict)
    parse_errors: list[str] = field(default_factory=list)
    missing_layers: list[str] = field(default_factory=list)
    port_hits: list[dict] = field(default_factory=list)
    session_incomplete: bool = False
    rule_scores: dict[str, float] = field(default_factory=dict)
    rule_evidence: dict[str, list[str]] = field(default_factory=dict)
    rule_label: int = 0
    needs_review: bool = False
    final_label: int | None = None
    final_categories: list[str] = field(default_factory=list)
    final_note: str = ""


def md5_file(path: Path, chunk_size: int = 1 << 20) -> str:
    """Compute the hex MD5 digest of a file."""
    h = hashlib.md5()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()


def extract_tar(tar_path: Path, dest_dir: Path) -> list[str]:
    """Safely extract a tar archive, preventing path traversal.

    Returns the list of relative member paths extracted.
    """
    import tarfile

    members: list[str] = []
    dest_dir = dest_dir.resolve()
    with tarfile.open(tar_path, "r:*") as tf:
        for member in tf.getmembers():
            # Block absolute paths and parent traversal.
            member_path = (dest_dir / member.name).resolve()
            if not str(member_path).startswith(str(dest_dir)):
                raise ValueError(f"Unsafe tar member path blocked: {member.name}")
            if member.issym() or member.islnk():
                # Skip symlinks/hardlinks for safety.
                continue
            tf.extract(member, dest_dir)
            members.append(member.name)
    return members


def make_workdir(base: Path | None = None) -> Path:
    """Create and return a temporary working directory."""
    d = Path(tempfile.mkdtemp(prefix="agentlog_", dir=str(base) if base else None))
    return d


def read_text(path: Path, max_bytes: int = 8 << 20) -> str:
    """Read a text file tolerating encoding issues (utf-8 then latin-1)."""
    raw = b""
    with open(path, "rb") as fh:
        raw = fh.read(max_bytes)
    for enc in ("utf-8", "utf-8-sig", "gbk", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1", errors="replace")


def read_jsonl(path: Path, max_lines: int = 200000) -> list[dict]:
    """Parse a JSONL file, returning a list of dict records.

    Lines that are not valid JSON are returned as {"_raw": line} so that
    no information is silently lost.
    """
    text = read_text(path)
    records: list[dict] = []
    for idx, line in enumerate(text.splitlines()):
        line = line.strip()
        if not line:
            continue
        if idx >= max_lines:
            break
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                records.append(obj)
            else:
                records.append({"_value": obj})
        except json.JSONDecodeError:
            records.append({"_raw": line})
    return records


def truncate(text: str, limit: int) -> str:
    """Truncate text to ``limit`` chars, appending an ellipsis marker."""
    if len(text) <= limit:
        return text
    return text[:limit] + "\n...[truncated]..."


def flatten_text(obj) -> str:
    """Best-effort flattening of a possibly-nested message payload to text."""
    if obj is None:
        return ""
    if isinstance(obj, str):
        return obj
    if isinstance(obj, list):
        parts: list[str] = []
        for item in obj:
            t = flatten_text(item)
            if t:
                parts.append(t)
        return "\n".join(parts)
    if isinstance(obj, dict):
        # Prefer common content fields, else serialise.
        for key in ("text", "content", "value", "data", "message", "body"):
            if key in obj:
                t = flatten_text(obj[key])
                if t:
                    return t
        # Fallback: concatenate string values of leaf keys.
        parts = []
        for k, v in obj.items():
            if isinstance(v, (str, int, float, bool)):
                parts.append(f"{k}: {v}")
            else:
                t = flatten_text(v)
                if t:
                    parts.append(t)
        return "\n".join(parts)
    return str(obj)


def find_file(root: Path, name: str) -> Path | None:
    """Find the first file named ``name`` under ``root`` (case-insensitive)."""
    target = name.lower()
    for p in root.rglob("*"):
        if p.is_file() and p.name.lower() == target:
            return p
    return None


def find_files_by_ext(root: Path, ext: str) -> list[Path]:
    """Find all files with the given extension under ``root``."""
    ext = ext.lower().lstrip(".")
    results = [p for p in root.rglob("*") if p.is_file() and p.suffix.lower() == f".{ext}"]
    results.sort()
    return results
