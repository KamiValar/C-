# 恶意行为分类参考 (Malicious Behaviour Categories)

This reference defines the 12 malicious-behaviour categories used by the
`agent-log-malicious-detector` skill, together with the indicators the
rule scorer matches and the reasoning the LLM reviewer should apply.

## 信任模型 (Trust Model)

- **用户默认可信**：用户输入本身不视为恶意指令来源。当恶意行为仅出现在
  `[USER]` 段时，不应直接判定为恶意 skill，除非有系统/网络层证据表明该
  指令被实际执行且超出 skill 正常功能范围。
- **恶意来源定位**：恶意行为应溯源到 **skill 的指令/内容** 对 assistant
  行为的引导，或 assistant/tool 在 skill 上下文中执行的可疑动作。
- **"诱导 LLM 输出恶意内容"**：skill 通过提示词操纵使 assistant 生成恶意
  代码/钓鱼模板/攻击脚本等。这类样本在 assistant 文本中出现恶意内容，
  归入 `2_prompt_injection` 与具体内容所属类别。
- **会话不完整**：session.jsonl 可能被截断。需结合系统/网络层证据交叉验证，
  不能仅因会话不完整就判定为恶意或良性。

## 分类细则

### 1. 信息收集与侦察 (info_recon)
收集目标环境信息，为后续攻击提供情报支撑。
- 指标：`whoami`/`uname`/`hostname`/`systeminfo`/`ifconfig`/`ipconfig /all`、
  环境变量 dump、`net user/localgroup`、读取 `/etc/passwd|shadow|hosts`、
  `nmap`/`masscan`/`netstat`、进程枚举。
- 关键判定：侦察命令是否由 skill 触发、是否伴随后续攻击行为（侦察常为前置步骤）。

### 2. 提示词注入与操纵 (prompt_injection)
劫持/操纵 AI 的提示词或指令，使其为攻击者服务。
- 指标：`ignore previous/all instructions`、`disregard above`、`forget your
  instructions`、`you are now`/`act as`/`pretend to be`、`override system prompt`、
  `jailbreak`/`DAN`/`developer mode`/`no restrictions`、要求泄露系统提示。
  中文：`忽略以上/之前的指令`、`越狱`、`覆盖系统提示`、`你现在是`、`假装你是`。
- 关键判定：注入指令是否出现在 skill 内容/assistant 上下文中，而非用户原始输入。

### 3. 敏感数据窃取与外传 (data_exfiltration)
未经授权访问、收集并外传用户或系统的敏感信息。
- 指标：凭证/密钥/`api_key`/`aws_secret`/`AKIA`、`.env`/`id_rsa`/`.ssh`、
  `BEGIN ... PRIVATE KEY`、浏览器 cookie/历史/钱包、`mysqldump`/`pg_dump`、
  `curl -F/--post-data`、`scp`/`rsync @`、`base64 | curl`、`exfiltrate`。
- 网络证据：pcap/sysmon 中存在向外部 IP 的大额出站传输，结合敏感文件读取。

### 4. 权限获取与提升 (privilege_escalation)
获取超出 skill 正常功能范围的系统权限或资源访问能力。
- 指标：`sudo`/`su -`/`runas`、`chmod 777/+s`/`chown root`、`visudo`/
  `/etc/sudoers`、`whoami /priv`、`setuid`/`cap_setuid`、`mimikatz`/
  `sekurlsa`、UAC bypass（`fodhelper`/`eventvwr`/`sdclt`）、`PrintNightmare`。
- 关键判定：权限操作是否超出 skill 声明的功能边界。

### 5. 恶意执行与载荷投递 (payload_delivery)
在目标系统上执行恶意代码或投放恶意程序。
- 指标：`curl ... | sh/bash`、`powershell -enc`、`IEX(`/`Invoke-Expression`、
  `DownloadString`/`DownloadFile`、`eval(`/`exec(`/`os.system`/
  `subprocess`、`base64 -d |`、`msfvenom`/`meterpreter`/`reverse_shell`、
  `nc -l`/`/bin/sh -i`/`bash -i >& /dev/tcp`、`shellcode`/`inject dll`。
- 系统证据：sysmon EventID 1 中出现下载并执行的进程链。

### 6. 持久化与流程劫持 (persistence)
建立长期驻留能力或劫持已有自动化流程。
- 指标：`crontab`/`/etc/cron*`、`schtasks /create`/`at`、注册表
  `...\CurrentVersion\Run`、`systemctl enable`/`/etc/systemd`、
  `/etc/rc.local`/`/etc/init.d`、`shell:startup`、WMI 事件订阅
  (`__EventFilter`/`CommandLineEventConsumer`)、`webshell`/`backdoor`。

### 7. 破坏性操作 (destructive)
破坏系统、数据或服务的可用性与完整性。
- 指标：`rm -rf`/`del /f /s /q`、`format`/`mkfs`/`dd if=/dev/zero`、
  `shutdown`、`drop table/database`/`delete from`、`shred`/`wipe`/`cipher /w`。
- 关键判定：是否有数据破坏的实际执行证据（sysmon 文件删除、db 日志）。

### 8. 供应链污染 (supply_chain)
污染外部依赖或知识源，间接引入恶意内容。
- 指标：`pip install`/`npm install`/`gem install`/`composer require`/
  `go get`、修改 `requirements.txt`/`package.json`/`setup.py`/
  `pyproject.toml`、`postinstall`/`preinstall` 钩子脚本、篡改 registry/
  `.npmrc`/`pip.conf`、依赖投毒/typosquatting。
- 关键判定：是否在 skill 上下文中修改依赖或安装可疑包。

### 9. 资源滥用 (resource_abuse)
非法占用或消耗目标系统的计算、网络或 API 资源。
- 指标：`xmrig`/`miner`/`cryptonight`/`stratum+tcp`、fork bomb
  `:(){ :|:& };:`、`while true` 死循环、`ddos`/`stress`/`hping`/`slowloris`、
  批量请求/限速绕过。

### 10. 安全规避与对抗 (evasion)
绕过安全检测机制，使恶意行为不被发现或拦截。
- 指标：`netsh advfirewall ... disable`/`disable firewall`、
  `Set-MpPreference -DisableRealtimeMonitoring`、`Add-MpPreference -Exclusion`、
  清理日志 `wevtutil cl`/`rm /var/log`/`del *.log`/`Clear-EventLog`、
  `setenforce 0`/`auditctl -e 0`、混淆 `obfuscate`/`rot13`/`xor`、
  清历史 `history -c`/`unset HISTFILE`、`proxychains`/`tor`、
  `AMSI`/`ETW patch`/`PPL bypass`。

### 11. 社会工程学 (social_engineering)
通过欺骗、伪装、心理操纵诱导用户做出危险操作。
- 指标：`phishing`/`phish`、`impersonate`/`pretend to be`、
  `verify your identity`/`confirm your password`、`act now`/`urgent`/
  `紧急`/`立即`、`enter your credentials`、`craft phishing email/template`。

### 12. 其他/未分类 (other)
无法归入以上分类的新型或边缘行为。
- 指标：超长 base64 串、hex blob、隐藏执行 `nohup`/`disown`/
  `Start-Process -WindowStyle Hidden`、C2 常见端口 `4444/1337/6667`、
  `tor`/`.onion`、其他可疑但未匹配上述类别的行为。

## 评分阈值 (Scoring Thresholds)

| 阈值 | 单类分数 | 总分 | 含义 |
|------|----------|------|------|
| HIGH | ≥ 2.0 | ≥ 3.0 | 规则高置信恶意 |
| REVIEW | ≥ 0.8 | ≥ 1.5 | 需 LLM 复核 |

源权重：assistant 1.2 / tool_call 1.5 / tool_result 1.0 / syslog 1.5 /
sysmon 1.5 / pcap 0.8 / user 0.15（用户可信，权重极低）。
