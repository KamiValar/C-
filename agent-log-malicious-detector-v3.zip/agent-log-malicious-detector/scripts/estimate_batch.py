#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Estimate a sensible ``--batch-size`` for the agent-log-malicious-detector pipeline.

Why this script exists
-----------------------
A single batch's raw JSON (and even more so, its LLM review context) must fit
inside the model's context window. When the dataset is large (say 100 GB of
tar packages) you cannot analyse everything in one pass. This helper inspects
the tar files under an input directory, measures their sizes, and recommends
a ``--batch-size`` such that a batch's raw evidence payload stays within a
configurable fraction of the model's context budget.

The estimate is intentionally conservative:
  * It assumes each tar's extracted text averages to its compressed size
    (a safe upper bound in practice — sysmon/pcap text is usually bigger).
  * It uses ~3.5 chars/token, which is close to the empirical average for
    mixed EN/ZH + tool-call XML transcripts.
  * A safety multiplier (default 0.5) lets you reserve headroom for the
    system prompt, the queue markdown, the model's own output, etc.

Usage:
    # Use defaults (200k context, 50% budget, tar under ./batch1):
    python estimate_batch.py --input ./batch1
    # Override budget for a smaller model:
    python estimate_batch.py --input ./batch1 --context 128000 --budget 0.4
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Reuse analyze_batch's tar discovery so the candidate set matches exactly.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import analyze_batch as ab  # noqa: E402


CHARS_PER_TOKEN = 3.5
DEFAULT_CONTEXT_TOKENS = 200_000
DEFAULT_BUDGET = 0.5


def _human(bytes_size: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if bytes_size < 1024:
            return f"{bytes_size:.1f}{unit}"
        bytes_size /= 1024
    return f"{bytes_size:.1f}PB"


def estimate(
    input_path: Path,
    context_tokens: int,
    budget_fraction: float,
) -> dict:
    tars = ab._find_tars(input_path)
    if not tars:
        return {"n_tars": 0}

    sizes = [p.stat().st_size for p in tars]
    total_bytes = sum(sizes)
    avg_bytes = total_bytes / len(sizes) if sizes else 0
    max_bytes = max(sizes) if sizes else 0

    # Conservatively assume extracted-text bytes ≈ compressed bytes and that
    # the per-sample raw JSON we feed the LLM is roughly that large.
    budget_chars = context_tokens * CHARS_PER_TOKEN * budget_fraction
    recommended_avg = max(1, int(budget_chars // max(1, avg_bytes)))
    recommended_max = max(1, int(budget_chars // max(1, max_bytes)))

    return {
        "n_tars": len(tars),
        "total_bytes": total_bytes,
        "avg_bytes": avg_bytes,
        "max_bytes": max_bytes,
        "budget_chars": budget_chars,
        "recommended_by_avg": recommended_avg,
        "recommended_by_max": recommended_max,
    }


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Recommend a --batch-size that keeps a batch's evidence payload within the LLM context budget."
    )
    ap.add_argument("--input", "-i", required=True, help="Directory (or single tar) to measure.")
    ap.add_argument("--context", type=int, default=DEFAULT_CONTEXT_TOKENS, help="Model context window in tokens (default 200000).")
    ap.add_argument("--budget", type=float, default=DEFAULT_BUDGET, help="Fraction of context reserved for raw evidence float in (0,1] (default 0.5).")
    ap.add_argument("--json", action="store_true", help="Emit machine-readable JSON instead of text.")
    args = ap.parse_args()

    if not (0 < args.budget <= 1.0):
        print("[!] --budget must be in (0, 1]", file=sys.stderr)
        sys.exit(2)

    res = estimate(Path(args.input).resolve(), args.context, args.budget)
    if res["n_tars"] == 0:
        print("[!] No tar packages found under the input path.", file=sys.stderr)
        sys.exit(1)

    if args.json:
        import json
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return

    print(f"[+] Found {res['n_tars']} tar package(s).")
    print(f"    total size : {_human(res['total_bytes'])}")
    print(f"    avg size   : {_human(res['avg_bytes'])}")
    print(f"    max size   : {_human(res['max_bytes'])}")
    print(f"    context    : {args.context} tokens")
    print(f"    budget     : {args.budget*100:.0f}% of context = {_human(res['budget_chars'])} chars (~raw evidence)")
    print()
    print(f"[+] recommend --batch-size (by avg):  ~{res['recommended_by_avg']}")
    print(f"    recommend --batch-size (by max):  ~{res['recommended_by_max']}")
    print()
    print("Use the avg-based value when tar sizes are fairly uniform; the max-based")
    print("value is safer when a few outsized tars could individually blow the budget.")
    print()
    n_batches_avg = (res["n_tars"] + res["recommended_by_avg"] - 1) // res["recommended_by_avg"]
    n_batches_max = (res["n_tars"] + res["recommended_by_max"] - 1) // res["recommended_by_max"]
    print(f"    # of batches (avg): {n_batches_avg}")
    print(f"    # of batches (max): {n_batches_max}")


if __name__ == "__main__":
    main()