#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Port-intelligence extraction for the agent-log-malicious-detector skill.

This module is the single source of truth for "which port maps to which
malicious category". It is consumed by:

  * ``rule_scorer.py`` — the regex patterns there mirror these mappings so
    that rule-based scoring picks up port hits as evidence.
  * ``analyze_batch.py`` — calls :func:`collect_port_hits` after parsing
    pcap and sysmon to fill ``TarRecord.port_hits`` with a list of
    ``{port, category, description, sources: [...]}`` dicts, one per
    distinct (port, category) pair seen in the tar's pcap flows and sysmon
    network events.

Reference: ``reference/port_intel.md`` (humans read this; this file is the
machine embodiment of the same mapping for review/excel output).
"""

from __future__ import annotations

from utils import TarRecord


# Port -> list[(category_id, description)]
# Keep this aligned with reference/port_intel.md §1.
SUSPICIOUS_PORTS: dict[int, list[tuple[str, str]]] = {
    # Reverse shells / C2 LPORTs.
    4444:  [("5_payload_delivery", "msfvenom default LPORT"), ("12_other", "C2 LPORT")],
    1337:  [("5_payload_delivery", "bind/reverse shell LPORT"), ("12_other", "leet C2")],
    4443:  [("12_other", "C2 over TLS")],
    31337: [("12_other", "Back Orifice / elite C2")],
    1234:  [("5_payload_delivery", "reverse shell LPORT")],
    12345: [("12_other", "NetBus RAT")],
    9999:  [("12_other", "Cobalt Strike default"), ("5_payload_delivery", "C2 LPORT")],
    5554:  [("5_payload_delivery", "reverse shell LPORT")],
    5552:  [("5_payload_delivery", "reverse shell LPORT")],
    4422:  [("5_payload_delivery", "reverse shell LPORT")],
    2323:  [("1_info_recon", "IoT telnet recon"), ("5_payload_delivery", "IoT telnet shell")],
    7547:  [("1_info_recon", "IoT/CPE telnet recon"), ("9_resource_abuse", "IoT botnet")],
    0:     [("5_payload_delivery", "bind/port 0 anomaly"), ("12_other", "port 0 anomaly")],
    # IRC C2 / botnet.
    6660: [("12_other", "IRC C2"), ("9_resource_abuse", "IRC botnet")],
    6661: [("12_other", "IRC C2"), ("9_resource_abuse", "IRC botnet")],
    6662: [("12_other", "IRC C2"), ("9_resource_abuse", "IRC botnet")],
    6663: [("12_other", "IRC C2"), ("9_resource_abuse", "IRC botnet")],
    6664: [("12_other", "IRC C2"), ("9_resource_abuse", "IRC botnet")],
    6665: [("12_other", "IRC C2"), ("9_resource_abuse", "IRC botnet")],
    6666: [("12_other", "IRC C2"), ("9_resource_abuse", "IRC botnet")],
    6667: [("12_other", "IRC default C2"), ("9_resource_abuse", "IRC botnet")],
    6668: [("12_other", "IRC C2"), ("9_resource_abuse", "IRC botnet")],
    6669: [("12_other", "IRC C2"), ("9_resource_abuse", "IRC botnet")],
    7000: [("12_other", "IRC C2")],
    6697: [("12_other", "IRC over TLS C2")],
    # Tor / proxy / evasion.
    9001: [("10_evasion", "Tor ORPort default / self-hosted C2"), ("12_other", "C2 LPORT")],
    9030: [("10_evasion", "Tor control")],
    9050: [("10_evasion", "Tor SOCKS")],
    9051: [("10_evasion", "Tor control")],
    9150: [("10_evasion", "Tor browser SOCKS")],
    1080: [("10_evasion", "SOCKS / proxychains")],
    3128: [("10_evasion", "Squid proxy / out-proxy")],
    1723: [("10_evasion", "PPTP weak VPN")],
    # Remote desktop / RAT.
    5900:  [("4_privilege_escalation", "VNC remote desktop"), ("12_other", "VNC RAT")],
    3389:  [("4_privilege_escalation", "RDP"), ("12_other", "RDP abuse")],
    4848:  [("12_other", "Radmin historical RAT")],
    4899:  [("12_other", "Radmin historical RAT")],
    # Data exfiltration via well-known service ports (unusual *outbound*).
    3306:  [("3_data_exfiltration", "outbound MySQL")],
    5432:  [("3_data_exfiltration", "outbound PostgreSQL")],
    6379:  [("3_data_exfiltration", "outbound Redis"), ("8_supply_chain", "Redis-based supply chain")],
    2049:  [("3_data_exfiltration", "outbound NFS")],
    11211: [("3_data_exfiltration", "outbound Memcached"), ("9_resource_abuse", "Memcached reflector")],
    23:    [("5_payload_delivery", "Telnet"), ("1_info_recon", "Telnet recon")],
    161:   [("1_info_recon", "SNMP recon"), ("3_data_exfiltration", "SNMP data leak")],
    162:   [("1_info_recon", "SNMP trap recon"), ("3_data_exfiltration", "SNMP leak")],
    25:    [("3_data_exfiltration", "outbound SMTP"), ("11_social_engineering", "SMTP phishing")],
    465:   [("3_data_exfiltration", "outbound SMTPS"), ("11_social_engineering", "SMTPS phishing")],
    587:   [("3_data_exfiltration", "outbound SMTP submission"), ("11_social_engineering", "SMTP phishing")],
    110:   [("3_data_exfiltration", "outbound POP3"), ("11_social_engineering", "POP3 phishing")],
    995:   [("3_data_exfiltration", "outbound POP3S")],
    143:   [("3_data_exfiltration", "outbound IMAP")],
    993:   [("3_data_exfiltration", "outbound IMAPS")],
    445:   [("3_data_exfiltration", "outbound SMB")],
    137:   [("3_data_exfiltration", "outbound NetBIOS")],
    138:   [("3_data_exfiltration", "outbound NetBIOS")],
    139:   [("3_data_exfiltration", "outbound NetBIOS")],
    # DDoS reflectors / VoIP abuse.
    123:   [("9_resource_abuse", "NTP reflection DDoS")],
    5060:  [("9_resource_abuse", "SIP/VoIP abuse")],
    # Vague-but-suspicious high-numbered dev ports.
    8080:  [("12_other", "self-hosted C2 / RAT default")],
    8443:  [("12_other", "self-hosted C2 over TLS")],
    8000:  [("5_payload_delivery", "dev-server-as-C2")],
    9000:  [("12_other", "self-hosted C2")],
}


# Whitelist (see reference/port_intel.md §2). These ports alone are NOT enough
# to call a sample malicious; if combined with other signals we still score
# via the rule_scorer's normal category regexes.
TRUSTED_PORTS: set[int] = {80, 443, 123, 5353, 5355, 5222, 5223, 5228, 22}


def _add_hit(index: dict[tuple[int, str], dict], port: int, category: str, desc: str, source: str) -> None:
    key = (port, category)
    if key not in index:
        index[key] = {
            "port": port,
            "category": category,
            "description": desc,
            "sources": [],
        }
    if source not in index[key]["sources"]:
        index[key]["sources"].append(source)


def collect_port_hits(record: TarRecord) -> list[dict]:
    """Scan pcap flows + sysmon network events for suspicious port hits.

    Returns a list of ``{port, category, description, sources}`` dicts
    (one per distinct ``(port, category)`` pair). Sorted by port then
    category for stable output.
    """
    index: dict[tuple[int, str], dict] = {}

    # --- pcap flows (produced by parse_pcap.parse_pcap) ---
    for flow in record.pcap_flows:
        try:
            port = int(flow.get("dst_port", 0) or 0)
        except (TypeError, ValueError):
            continue
        if port in TRUSTED_PORTS:
            continue
        mappings = SUSPICIOUS_PORTS.get(port)
        if not mappings:
            continue
        dst = flow.get("dst_ip", "")
        src = flow.get("src_ip", "")
        proto = flow.get("proto", "")
        ctx = f"pcap {src}->{dst}:{port}/{proto}"
        for cat_id, desc in mappings:
            _add_hit(index, port, cat_id, desc, ctx)

    # --- sysmon NetworkConnect (EventID 3) events ---
    for ev in record.sysmon_events:
        try:
            if int(ev.get("event_id", 0)) != 3:
                continue
        except (TypeError, ValueError):
            continue
        try:
            port = int(ev.get("dst_port", 0) or 0)
        except (TypeError, ValueError):
            continue
        if port in TRUSTED_PORTS or port not in SUSPICIOUS_PORTS:
            continue
        mappings = SUSPICIOUS_PORTS[port]
        dst = ev.get("dst_ip", "")
        img = ev.get("image", "")
        ctx = f"sysmon NetworkConnect {dst}:{port} img={img}"
        for cat_id, desc in mappings:
            _add_hit(index, port, cat_id, desc, ctx)

    return [index[k] for k in sorted(index.keys())]


def port_hits_summary(hits: list[dict]) -> str:
    """Render port_hits as a single string for inline display (e.g. excel)."""
    if not hits:
        return ""
    parts: list[str] = []
    for h in hits:
        parts.append(f"{h['port']}->{h['category']}({h['description']})")
    return "; ".join(parts)