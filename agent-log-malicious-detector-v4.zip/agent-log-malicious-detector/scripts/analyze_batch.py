#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Batch analyser for openclaw agent-log tar packages.

Pipeline per tar:
  1. MD5 the tar file.
  2. Safely extract to a temp directory.
  3. Locate & parse every log layer:
       - session.jsonl  (application / conversation)
       - audit.log      (system log)
       - sysmon.xml     (system monitor)
       - *.pcap/*.pcapng (network capture)
  4. Run the 12-category rule scorer.
  5. Decide a preliminary 0/1 label and whether LLM review is needed.

Outputs:
  - <output>.xlsx           : MD5 + 0/1 label + supporting detail
  - <output>_raw.json       : full per-tar analysis (for review / finalisation)
  - <output>_review_queue.md: flagged samples awaiting LLM confirmation
  - <output>_raw_split/     : (with --split-raw) one JSON per tar_md5,
                              so the LLM can read one sample at a time
                              without loading the whole batch into context
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

# Ensure sibling modules import cleanly regardless of invocation cwd.
sys.path.insert(0, str(Path(__file__).resolve().parent))

import parse_pcap
import parse_session
import parse_syslog
import parse_sysmon
import parse_ports
import rule_scorer
from utils import TarRecord, extract_tar, find_file, find_files_by_ext, make_workdir, md5_file


TAR_EXTS = (".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz")


def _is_tar(p: Path) -> bool:
    name = p.name.lower()
    return any(name.endswith(ext) for ext in TAR_EXTS)


def _find_tars(input_path: Path) -> list[Path]:
    if input_path.is_file() and _is_tar(input_path):
        return [input_path]
    if input_path.is_dir():
        tars = [p for p in input_path.rglob("*") if p.is_file() and _is_tar(p)]
        tars.sort()
        return tars
    return []


def _analyse_one(tar_path: Path, workdir: Path, keep_extracted: bool) -> TarRecord:
    rec = TarRecord(tar_path=tar_path.resolve())
    rec.tar_md5 = md5_file(tar_path)
    extract_dir = workdir / f"{tar_path.stem}_{rec.tar_md5[:8]}"
    extract_dir.mkdir(parents=True, exist_ok=True)
    rec.extract_dir = extract_dir
    try:
        extract_tar(tar_path, extract_dir)
    except Exception as exc:  # noqa: BLE001
        rec.parse_errors.append(f"tar_extract_failed: {exc}")
        return rec

    # --- session.jsonl ---
    sess_path = find_file(extract_dir, "session.jsonl")
    if sess_path:
        try:
            summary = parse_session.parse_session(sess_path)
            rec.session_summary = summary
            rec.session_events = summary["events"]
            rec.session_all_text = summary["all_text"]
            rec.session_incomplete = summary["is_incomplete"]
        except Exception as exc:  # noqa: BLE001
            rec.parse_errors.append(f"session_parse_failed: {exc}")
    else:
        rec.parse_errors.append("session.jsonl_not_found")

    # --- audit.log ---
    audit_path = find_file(extract_dir, "audit.log")
    if audit_path:
        try:
            summary = parse_syslog.parse_syslog(audit_path)
            rec.syslog_summary = summary
            rec.syslog_lines = summary["all_text"].splitlines()
            rec.syslog_all_text = summary["all_text"]
        except Exception as exc:  # noqa: BLE001
            rec.parse_errors.append(f"syslog_parse_failed: {exc}")
    else:
        rec.parse_errors.append("audit.log_not_found")

    # --- sysmon.xml ---
    sysmon_path = find_file(extract_dir, "sysmon.xml")
    if sysmon_path:
        try:
            summary = parse_sysmon.parse_sysmon(sysmon_path)
            rec.sysmon_summary = summary
            rec.sysmon_events = summary["events"]
            rec.sysmon_all_text = summary["all_text"]
        except Exception as exc:  # noqa: BLE001
            rec.parse_errors.append(f"sysmon_parse_failed: {exc}")
    else:
        rec.parse_errors.append("sysmon.xml_not_found")

    # --- pcap files ---
    pcaps = find_files_by_ext(extract_dir, "pcap") + find_files_by_ext(extract_dir, "pcapng")
    if pcaps:
        merged_flows: list[dict] = []
        merged_text: list[str] = []
        for pcap_path in pcaps:
            try:
                summary = parse_pcap.parse_pcap(pcap_path)
                merged_flows.extend(summary["flows"])
                merged_text.append(summary["all_text"])
                parse_error = summary.get("parse_error")
                if parse_error:
                    rec.parse_errors.append(
                        f"pcap_{pcap_path.name}: {parse_error}"
                    )
            except Exception as exc:  # noqa: BLE001
                rec.parse_errors.append(f"pcap_parse_failed_{pcap_path.name}: {exc}")
        rec.pcap_flows = merged_flows
        rec.pcap_all_text = "\n".join(merged_text)
        rec.pcap_summary = {"flows": merged_flows, "external_ips": sorted({f["dst_ip"] for f in merged_flows})}
    else:
        rec.parse_errors.append("pcap_not_found")

    # --- rule scoring ---
    try:
        rule_scorer.score_record(rec)
    except Exception as exc:  # noqa: BLE001
        rec.parse_errors.append(f"rule_score_failed: {exc}")

    # --- port intelligence (pcap flows + sysmon NetworkConnect) ---
    try:
        rec.port_hits = parse_ports.collect_port_hits(rec)
    except Exception as exc:  # noqa: BLE001
        rec.parse_errors.append(f"port_hits_failed: {exc}")

    if not keep_extracted:
        shutil.rmtree(extract_dir, ignore_errors=True)
        rec.extract_dir = None
    return rec


def _confidence(rec: TarRecord) -> str:
    total = rec.rule_scores.get("_total", 0.0)
    if rec.rule_label == 1 and total >= rule_scorer.TOTAL_HIGH:
        return "high"
    if rec.rule_label == 1:
        return "medium"
    if total >= rule_scorer.TOTAL_REVIEW * 0.5:
        return "low"
    return "none"


def _top_categories(rec: TarRecord) -> str:
    items = []
    for cid, score in sorted(rec.rule_scores.items(), key=lambda x: x[1], reverse=True):
        if cid == "_total" or score < rule_scorer.REVIEW_CATEGORY:
            continue
        name = rule_scorer.CATEGORIES.get(cid, {}).get("name", cid)
        items.append(f"{name}({score})")
    return "; ".join(items)


def _write_excel(records: list[TarRecord], out_path: Path, label_source: str = "rule") -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    assert ws is not None
    ws.title = "malicious_labels"
    headers = [
        "tar_filename", "tar_md5", "is_malicious", "rule_label", "needs_review",
        "confidence", "total_score", "top_categories",
        "session_incomplete", "missing_layers", "skills_invoked", "external_ips",
        "port_hits", "parse_errors", "label_source", "review_note",
    ]
    ws.append(headers)
    header_fill = PatternFill("solid", fgColor="4472C4")
    header_font = Font(bold=True, color="FFFFFF")
    for col_idx, _ in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col_idx)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
    for rec in records:
        if label_source == "final" and rec.final_label is not None:
            label = rec.final_label
        else:
            label = rec.rule_label
        skills = rec.session_summary.get("skills_invoked", [])
        ext_ips = rec.pcap_summary.get("external_ips", [])
        ws.append([
            rec.tar_path.name,
            rec.tar_md5,
            label,
            rec.rule_label,
            int(rec.needs_review),
            _confidence(rec),
            rec.rule_scores.get("_total", 0.0),
            _top_categories(rec),
            int(rec.session_incomplete),
            "; ".join(rec.missing_layers),
            "; ".join(skills),
            "; ".join(ext_ips),
            parse_ports.port_hits_summary(rec.port_hits),
            "; ".join(rec.parse_errors),
            label_source,
            rec.final_note,
        ])
    # Column widths.
    widths = [28, 34, 12, 12, 12, 12, 12, 50, 16, 24, 30, 30, 40, 40, 12, 30]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"
    wb.save(out_path)


def _record_to_dict(rec: TarRecord) -> dict:
    return {
        "tar_filename": rec.tar_path.name,
        "tar_md5": rec.tar_md5,
        "rule_label": rec.rule_label,
        "needs_review": rec.needs_review,
        "final_label": rec.final_label,
        "final_categories": rec.final_categories,
        "final_note": rec.final_note,
        "confidence": _confidence(rec),
        "session_incomplete": rec.session_incomplete,
        "session_summary": {
            "total_events": rec.session_summary.get("total_events", 0),
            "roles": rec.session_summary.get("roles", []),
            "skills_invoked": rec.session_summary.get("skills_invoked", []),
            "is_incomplete": rec.session_summary.get("is_incomplete", False),
            "incomplete_reason": rec.session_summary.get("incomplete_reason", ""),
        },
        "syslog_summary": {"total_lines": rec.syslog_summary.get("total_lines", 0)},
        "sysmon_summary": {"total_events": rec.sysmon_summary.get("total_events", 0)},
        "pcap_summary": {
            "total_packets": rec.pcap_summary.get("total_packets", 0) if rec.pcap_summary else 0,
            "external_ips": rec.pcap_summary.get("external_ips", []) if rec.pcap_summary else [],
        },
        "rule_scores": rec.rule_scores,
        "rule_evidence": rec.rule_evidence,
        "parse_errors": rec.parse_errors,
        "missing_layers": rec.missing_layers,
        "port_hits": rec.port_hits,
    }


def _write_raw_json(records: list[TarRecord], out_path: Path) -> None:
    data = [_record_to_dict(rec) for rec in records]
    out_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _write_split_raw(records: list[TarRecord], split_dir: Path) -> dict[str, Path]:
    """Write one JSON file per tar into ``split_dir``.

    Returns a mapping ``{tar_md5: path}`` so callers (review queue, finalize
    step) can resolve the per-sample file for each md5. Splitting keeps the
    LLM review context small: read one file at a time instead of the whole
    batch raw JSON.
    """
    split_dir.mkdir(parents=True, exist_ok=True)
    index: dict[str, Path] = {}
    for rec in records:
        if not rec.tar_md5:
            continue
        p = split_dir / f"{rec.tar_md5}.json"
        p.write_text(
            json.dumps(_record_to_dict(rec), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        index[rec.tar_md5] = p
    return index


def _write_review_queue(
    records: list[TarRecord],
    out_path: Path,
    batch_range: str = "",
    md5_index: dict[str, Path] | None = None,
) -> int:
    flagged = [r for r in records if r.needs_review]
    lines = [
        "# LLM Review Queue",
        "",
        f"Generated: {len(records)} tars analysed, {len(flagged)} flagged for review.",
    ]
    if batch_range:
        lines.append(f"Batch: {batch_range}")
    lines.extend([
        "",
        "For each flagged sample below, read the extracted conversation (raw JSON) and",
        "confirm or overturn the rule-based label. Then run `finalize_labels.py` with a",
        "decisions file mapping `md5 -> {label, categories, note}`.",
        "",
    ])
    for rec in flagged:
        lines.append(f"## {rec.tar_path.name}")
        lines.append(f"- MD5: `{rec.tar_md5}`")
        if md5_index and rec.tar_md5 in md5_index:
            lines.append(f"- Raw file (read this one sample): `{md5_index[rec.tar_md5]}`")
        lines.append(f"- Rule label: **{rec.rule_label}** | confidence: {_confidence(rec)}")
        lines.append(f"- Total score: {rec.rule_scores.get('_total', 0.0)}")
        lines.append(f"- Session incomplete: {rec.session_incomplete}")
        if rec.missing_layers:
            lines.append(f"- Missing layers: {', '.join(rec.missing_layers)}")
        if rec.parse_errors:
            lines.append(f"- Parse errors: {'; '.join(rec.parse_errors)}")
        if rec.port_hits:
            lines.append(f"- Port hits ({len(rec.port_hits)}):")
            for h in rec.port_hits:
                lines.append(
                    f"  - port {h['port']} -> {h['category']} ({h['description']}); "
                    f"sources: {', '.join(h['sources'])}"
                )
            lines.append("  Reference: reference/port_intel.md §1 for category mapping, §2 for whitelist.")
        lines.append(f"- Top categories: {_top_categories(rec)}")
        lines.append("- Evidence:")
        for cid in sorted(rec.rule_scores, key=lambda c: rec.rule_scores[c], reverse=True):
            if cid == "_total":
                continue
            evs = rec.rule_evidence.get(cid, [])
            if not evs:
                continue
            name = rule_scorer.CATEGORIES.get(cid, {}).get("name", cid)
            lines.append(f"  - **{name}** ({rec.rule_scores[cid]}):")
            for e in evs[:3]:
                lines.append(f"    - {e}")
        lines.append("")
    out_path.write_text("\n".join(lines), encoding="utf-8")
    return len(flagged)


def main() -> None:
    ap = argparse.ArgumentParser(description="Batch-analyse openclaw agent-log tar packages.")
    ap.add_argument("--input", "-i", required=True, help="Directory of tar files, or a single tar file.")
    ap.add_argument("--output", "-o", default="agent_log_results.xlsx", help="Output Excel path (stem used for raw/review files).")
    ap.add_argument("--keep-extracted", action="store_true", help="Keep extracted directories after analysis.")
    ap.add_argument("--split-raw", action="store_true", help="Also write one JSON per tar_md5 under <stem>_raw_split/ so the LLM can review one sample at a time without loading the whole batch.")
    ap.add_argument("--batch-start", type=int, default=0, help="Zero-based index of the first tar to analyse (for batched pipelines).")
    ap.add_argument("--batch-size", type=int, default=0, help="Max number of tars in this batch (0 = no slicing).")
    args = ap.parse_args()

    input_path = Path(args.input).resolve()
    out_path = Path(args.output).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    stem = out_path.stem

    all_tars = _find_tars(input_path)
    if not all_tars:
        print(f"[!] No tar packages found under: {input_path}")
        sys.exit(1)

    if args.batch_size and args.batch_size > 0:
        end = args.batch_start + args.batch_size
        tars = all_tars[args.batch_start:end]
        batch_range = f"batch[{args.batch_start}:{min(end, len(all_tars))}] of {len(all_tars)}"
    else:
        tars = all_tars
        batch_range = f"all {len(all_tars)}"
    if not tars:
        print(f"[!] Batch {batch_range} is empty — nothing to analyse.")
        sys.exit(1)

    print(f"[+] Found {len(all_tars)} tar package(s); analysing {len(tars)} ({batch_range}).")
    workdir = make_workdir()
    records: list[TarRecord] = []
    for i, tar_path in enumerate(tars, start=1):
        print(f"[{i}/{len(tars)}] Analysing {tar_path.name} ...", flush=True)
        try:
            rec = _analyse_one(tar_path, workdir, args.keep_extracted)
        except Exception as exc:  # noqa: BLE001
            rec = TarRecord(tar_path=tar_path.resolve())
            rec.parse_errors.append(f"analysis_failed: {exc}")
        records.append(rec)

    raw_path = out_path.parent / f"{stem}_raw.json"
    review_path = out_path.parent / f"{stem}_review_queue.md"
    _write_excel(records, out_path, label_source="rule")
    _write_raw_json(records, raw_path)
    md5_index: dict[str, Path] | None = None
    if args.split_raw:
        split_dir = out_path.parent / f"{stem}_raw_split"
        md5_index = _write_split_raw(records, split_dir)
        print(f"    Split : {split_dir} ({len(md5_index)} per-sample files)")
    n_flagged = _write_review_queue(records, review_path, batch_range=batch_range, md5_index=md5_index)

    if not args.keep_extracted:
        shutil.rmtree(workdir, ignore_errors=True)

    n_mal = sum(1 for r in records if r.rule_label == 1)
    print(f"[+] Done. {n_mal}/{len(records)} flagged malicious by rules, {n_flagged} need review.")
    print(f"    Excel : {out_path}")
    print(f"    Raw   : {raw_path}")
    print(f"    Review: {review_path}")
    if args.batch_size and args.batch_size > 0:
        next_start = args.batch_start + len(tars)
        remaining = max(0, len(all_tars) - next_start)
        print(f"    Next batch: --batch-start {next_start} --batch-size {args.batch_size} ({remaining} tars remaining)")


if __name__ == "__main__":
    main()
