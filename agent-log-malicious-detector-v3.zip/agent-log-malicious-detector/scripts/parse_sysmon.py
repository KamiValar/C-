#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Parser for ``sysmon.xml`` system-layer logs (Windows Sysmon).

Supports Windows Event XML (the standard Sysmon export) and plain
``<event>``/``<Event>`` style XML. Namespaces are stripped so the same
field extraction logic works regardless of schema variant.

Extracted high-signal events:
  * EventID 1  - Process creation (image, command line, parent)
  * EventID 3  - Network connection (src/dst IP, port, image)
  * EventID 10 - Process access (cross-process memory read)
  * EventID 11 - File creation
  * EventID 12/13/14 - Registry modification
  * EventID 22 - DNS query
"""

from __future__ import annotations

import io
import re
from pathlib import Path

from defusedxml import ElementTree as ET

from utils import read_text


# EventID -> short label.
EVENT_LABELS = {
    1: "ProcessCreate",
    3: "NetworkConnect",
    8: "CreateRemoteThread",
    9: "RawAccessRead",
    10: "ProcessAccess",
    11: "FileCreate",
    12: "RegistryKeyChange",
    13: "RegistryValueSet",
    14: "RegistryRename",
    17: "PipeCreated",
    18: "PipeConnected",
    22: "DNSQuery",
    25: "ProcessTampering",
}


def _strip_ns(tag: str) -> str:
    return tag.split("}", 1)[-1] if "}" in tag else tag


def _local_findall(elem, tag: str):
    """findall that ignores XML namespaces."""
    target = tag.lower()
    return [c for c in elem.iter() if _strip_ns(c.tag).lower() == target]


def _local_find(elem, tag: str):
    for c in elem.iter():
        if _strip_ns(c.tag).lower() == tag.lower():
            return c
    return None


def _extract_event_data(event_elem) -> dict:
    """Pull EventData Name->Value pairs and System fields from one event."""
    data: dict[str, str] = {}
    ed = _local_find(event_elem, "EventData")
    if ed is not None:
        for d in ed:
            name = d.attrib.get("Name") or _strip_ns(d.tag)
            val = (d.text or "").strip()
            if name:
                data[name] = val
    system = _local_find(event_elem, "System")
    if system is not None:
        eid = _local_find(system, "EventID")
        if eid is not None and eid.text:
            data["EventID"] = eid.text.strip()
        tc = _local_find(system, "TimeCreated")
        if tc is not None and tc.attrib.get("SystemTime"):
            data["TimeCreated"] = tc.attrib["SystemTime"]
        comp = _local_find(system, "Computer")
        if comp is not None and comp.text:
            data["Computer"] = comp.text.strip()
    # Fallback: if no EventData, gather leaf text of the event.
    if not data:
        for c in event_elem.iter():
            if c.text and c.text.strip() and len(list(c)) == 0:
                name = _strip_ns(c.tag)
                data.setdefault(name, c.text.strip())
    return data


def _normalise(raw_events: list[dict]) -> list[dict]:
    """Convert raw data dicts into typed event records."""
    out: list[dict] = []
    for ev in raw_events:
        try:
            eid = int(ev.get("EventID", 0) or 0)
        except ValueError:
            eid = 0
        label = EVENT_LABELS.get(eid, f"EventID_{eid}")
        rec = {"event_id": eid, "label": label, "data": ev}
        if eid == 1:
            rec["image"] = ev.get("Image", "")
            rec["command_line"] = ev.get("CommandLine", "")
            rec["parent_image"] = ev.get("ParentImage", "")
        elif eid == 3:
            rec["image"] = ev.get("Image", "")
            rec["dst_ip"] = ev.get("DestinationIp", "")
            rec["dst_port"] = ev.get("DestinationPort", "")
            rec["src_ip"] = ev.get("SourceIp", "")
            rec["protocol"] = ev.get("Protocol", "")
        elif eid == 11:
            rec["target_filename"] = ev.get("TargetFilename", "")
        elif eid in (12, 13, 14):
            rec["target_object"] = ev.get("TargetObject", "")
        elif eid == 22:
            rec["query_name"] = ev.get("QueryName", "")
        elif eid == 10:
            rec["source_image"] = ev.get("SourceImage", "")
            rec["target_image"] = ev.get("TargetImage", "")
        out.append(rec)
    return out


def _build_corpus(normalised: list[dict]) -> str:
    parts: list[str] = []
    for r in normalised:
        eid = r["event_id"]
        if eid == 1:
            parts.append(f"[ProcessCreate] {r.get('image','')} :: {r.get('command_line','')}")
        elif eid == 3:
            parts.append(f"[NetworkConnect] {r.get('src_ip','')} -> {r.get('dst_ip','')}:{r.get('dst_port','')} ({r.get('protocol','')}) img={r.get('image','')}")
        elif eid == 11:
            parts.append(f"[FileCreate] {r.get('target_filename','')}")
        elif eid in (12, 13, 14):
            parts.append(f"[Registry] {r.get('target_object','')}")
        elif eid == 22:
            parts.append(f"[DNSQuery] {r.get('query_name','')}")
        elif eid == 10:
            parts.append(f"[ProcessAccess] {r.get('source_image','')} -> {r.get('target_image','')}")
        else:
            d = r.get("data", {})
            compact = " ".join(f"{k}={v}" for k, v in d.items() if k not in ("EventID",))
            parts.append(f"[{r.get('label','')}] {compact}")
    return "\n".join(parts)


_EVENT_BLOCK_RE = re.compile(r"<Event[\s>].*?</Event>", re.IGNORECASE | re.DOTALL)
_EVENTID_RE = re.compile(r"<EventID[^>]*>(?P<eid>\d+)</EventID>", re.IGNORECASE)
_DATA_RE = re.compile(r'<Data\s+Name="(?P<name>[^"]+)"[^>]*>(?P<val>.*?)</Data>', re.IGNORECASE | re.DOTALL)


def _regex_extract_events(text: str) -> list[dict]:
    """Last-resort extraction of events from malformed XML via regex."""
    raw: list[dict] = []
    # Split into event blocks; if no <Event> wrappers, treat whole doc as one.
    blocks = _EVENT_BLOCK_RE.findall(text) or [text]
    for block in blocks:
        data: dict[str, str] = {}
        m = _EVENTID_RE.search(block)
        if m:
            data["EventID"] = m.group("eid")
        for dm in _DATA_RE.finditer(block):
            data[dm.group("name")] = dm.group("val").strip()
        # Also gather plain leaf elements like <CommandLine>...</CommandLine>.
        for tag in ("CommandLine", "Image", "DestinationIp", "DestinationPort",
                    "SourceIp", "TargetFilename", "TargetObject", "QueryName"):
            tm = re.search(rf"<{tag}[^>]*>(?P<val>.*?)</{tag}>", block, re.IGNORECASE | re.DOTALL)
            if tm and tag not in data:
                data[tag] = tm.group("val").strip()
        if data:
            raw.append(data)
    return raw


def parse_sysmon(path: Path) -> dict:
    """Parse ``sysmon.xml`` and return structured events + flat text corpus.

    Returns:
        events      - list of typed event dicts
        all_text    - flat text corpus for rule scoring
        total_events- int
        commands    - list of command lines from ProcessCreate events
        network     - list of dst_ip:dst_port strings
        parse_error - str (empty if fully parsed)
    """
    text = read_text(path)
    raw_events: list[dict] = []
    parse_error = ""
    try:
        root = ET.fromstring(text.encode("utf-8", errors="replace"))
    except ET.ParseError:
        try:
            root = ET.fromstring(f"<root>{text}</root>".encode("utf-8", errors="replace"))
        except ET.ParseError:
            # Regex fallback for malformed XML (e.g. unescaped ampersands).
            raw_events = _regex_extract_events(text)
            parse_error = "xml_regex_fallback"
            root = None
    if root is not None:
        event_elems = [e for e in root.iter() if _strip_ns(e.tag).lower() == "event"]
        if not event_elems:
            event_elems = [c for c in list(root) if _local_find(c, "EventID") is not None]
        for ev_elem in event_elems:
            data = _extract_event_data(ev_elem)
            if data:
                raw_events.append(data)
    normalised = _normalise(raw_events)
    commands = [r.get("command_line", "") for r in normalised if r["event_id"] == 1 and r.get("command_line")]
    network = [f"{r.get('dst_ip','')}:{r.get('dst_port','')}" for r in normalised if r["event_id"] == 3 and r.get("dst_ip")]
    return {
        "events": normalised,
        "all_text": _build_corpus(normalised) or text,
        "total_events": len(normalised),
        "commands": commands,
        "network": network,
        "parse_error": parse_error,
    }
