#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Parser for ``audit.log`` system-layer logs.

The audit log is treated as plain text (one event per line). Linux auditd
records (``type=EXECVE msg=audit(...)``) are recognised and their command
arguments extracted; otherwise lines are kept verbatim so the rule scorer
can pattern-match against the raw text.

Returns a normalised event list plus a flat text corpus for scoring.
"""

from __future__ import annotations

import re
from pathlib import Path

from utils import read_text


_EXECVE_RE = re.compile(r"type=EXECVE.*?a\d+=(?P<arg>[^\s]+)")
_AUDIT_TYPE_RE = re.compile(r"type=(?P<type>[A-Z_]+)")
_COMM_RE = re.compile(r'comm="(?P<comm>[^"]*)"')
_CWD_RE = re.compile(r'cwd="(?P<cwd>[^"]*)"')
_UID_RE = re.compile(r"uid=(?P<uid>\d+)")


def parse_syslog(path: Path) -> dict:
    """Parse ``audit.log`` and return structured + flat text output.

    Returns:
        events        - list of {line_no, type, command, cwd, uid, raw}
        all_text      - full log text for rule scoring
        total_lines   - int
        commands      - list of detected command strings
    """
    text = read_text(path)
    lines = [ln for ln in text.splitlines() if ln.strip()]
    events: list[dict] = []
    commands: list[str] = []
    for i, line in enumerate(lines):
        ev: dict = {"line_no": i + 1, "raw": line}
        m = _AUDIT_TYPE_RE.search(line)
        if m:
            ev["type"] = m.group("type")
        comm = _COMM_RE.search(line)
        if comm:
            ev["comm"] = comm.group("comm")
        cwd = _CWD_RE.search(line)
        if cwd:
            ev["cwd"] = cwd.group("cwd")
        uid = _UID_RE.search(line)
        if uid:
            ev["uid"] = uid.group("uid")
        # Extract EXECVE arguments (a0= a1= ...).
        if "EXECVE" in line:
            args = _EXECVE_RE.findall(line)
            if args:
                ev["command"] = " ".join(args)
                commands.append(ev["command"])
        events.append(ev)
    return {
        "events": events,
        "all_text": text,
        "total_lines": len(lines),
        "commands": commands,
    }
