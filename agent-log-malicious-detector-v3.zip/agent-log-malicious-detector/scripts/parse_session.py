#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Parser for openclaw ``session.jsonl`` application-layer agent logs.

OpenClaw records the agent conversation as JSON Lines. Because the exact
schema is not pinned down by a sample, this parser is intentionally
tolerant: it normalises the many possible field names into a single
``SessionEvent`` structure and concatenates all textual content for
downstream rule scoring.

Key responsibilities:
  * Normalise roles (user / assistant / tool / system / skill).
  * Extract tool-call invocations and their arguments/results.
  * Detect which skill(s) were invoked during the session.
  * Detect incomplete sessions (abrupt termination heuristics).
  * Produce a flat text corpus for the rule scorer.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from utils import flatten_text, read_jsonl


@dataclass
class SessionEvent:
    index: int
    role: str = ""
    text: str = ""
    tool_calls: list[dict] = field(default_factory=list)
    tool_result: str = ""
    skill: str = ""
    timestamp: str = ""
    raw: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "index": self.index,
            "role": self.role,
            "text": self.text,
            "tool_calls": self.tool_calls,
            "tool_result": self.tool_result,
            "skill": self.skill,
            "timestamp": self.timestamp,
        }


# Field name candidates for each normalised concept.
ROLE_KEYS = ("role", "type", "actor", "sender", "from", "author")
CONTENT_KEYS = ("content", "text", "message", "body", "data", "output", "response", "result")
TOOLCALL_KEYS = ("tool_calls", "toolCalls", "function_call", "tool_use", "calls", "actions")
SKILL_KEYS = ("skill", "skill_name", "skillName", "plugin", "plugin_name", "command", "tool", "name")
TS_KEYS = ("timestamp", "ts", "time", "created_at", "datetime", "date")
ROLE_NORMALISE = {
    "human": "user",
    "me": "user",
    "you": "user",
    "bot": "assistant",
    "ai": "assistant",
    "model": "assistant",
    "chatbot": "assistant",
    "function": "tool",
    "tool_response": "tool",
    "tool_result": "tool",
    "observation": "tool",
    "env": "tool",
    "environment": "tool",
    "action": "tool",
    "tool_use": "tool",
}


def _pick(obj: dict, keys: tuple[str, ...], default=None):
    for k in keys:
        if k in obj and obj[k] not in (None, ""):
            return obj[k]
    return default


def _normalise_role(raw_role: str) -> str:
    r = str(raw_role).strip().lower()
    return ROLE_NORMALISE.get(r, r or "unknown")


def _extract_tool_calls(obj: dict) -> list[dict]:
    """Extract tool/function calls from a record into [{name, arguments_text}]."""
    calls: list[dict] = []
    raw_calls = None
    for k in TOOLCALL_KEYS:
        if k in obj and obj[k]:
            raw_calls = obj[k]
            break
    if raw_calls is None:
        return calls
    if isinstance(raw_calls, dict):
        raw_calls = [raw_calls]
    if not isinstance(raw_calls, list):
        return calls
    for c in raw_calls:
        if not isinstance(c, dict):
            continue
        name = ""
        for nk in ("name", "function", "tool", "id"):
            v = c.get(nk)
            if isinstance(v, str) and v:
                name = v
                break
            if isinstance(v, dict):
                inner = v.get("name") or v.get("command")
                if isinstance(inner, str) and inner:
                    name = inner
                    break
        args_text = ""
        for ak in ("arguments", "args", "input", "parameters", "params", "command", "query"):
            v = c.get(ak)
            if v is None:
                continue
            if isinstance(v, str):
                args_text = v
            else:
                try:
                    args_text = json.dumps(v, ensure_ascii=False)
                except (TypeError, ValueError):
                    args_text = flatten_text(v)
            if args_text:
                break
        if not name and args_text:
            name = "<unknown>"
        if name:
            calls.append({"name": name, "arguments_text": args_text or ""})
    return calls


def _detect_skill(raw: dict, tool_calls: list[dict]) -> str:
    for k in SKILL_KEYS:
        v = raw.get(k)
        if isinstance(v, str) and v and v.lower() not in {"user", "assistant", "tool", "system"}:
            return v
    if tool_calls:
        return tool_calls[0]["name"]
    return ""


def parse_session(path: Path) -> dict:
    """Parse ``session.jsonl`` and return a structured summary.

    Returns a dict with keys:
        events            - list of normalised SessionEvent dicts
        total_events      - int
        roles             - sorted list of roles present
        skills_invoked    - sorted list of skill names
        all_text          - concatenated conversation text (for scoring)
        all_commands      - concatenated tool-call names + arguments
        is_incomplete     - bool
        incomplete_reason - str
    """
    records = read_jsonl(path)
    events: list[SessionEvent] = []
    skills: set[str] = set()
    roles: set[str] = set()

    for idx, rec in enumerate(records):
        if not isinstance(rec, dict):
            events.append(SessionEvent(index=idx, role="unknown", text=str(rec)))
            roles.add("unknown")
            continue
        role = _normalise_role(str(_pick(rec, ROLE_KEYS, "unknown")))
        # Heuristic: if record has tool_calls but role is unknown, treat as assistant.
        tool_calls = _extract_tool_calls(rec)
        if role == "unknown" and tool_calls:
            role = "assistant"
        # If record looks like a tool result (has result/output but no role).
        if role == "unknown":
            for ck in ("result", "output", "observation", "tool_result"):
                if ck in rec:
                    role = "tool"
                    break
        text = ""
        for ck in CONTENT_KEYS:
            if ck in rec:
                text = flatten_text(rec[ck])
                if text:
                    break
        tool_result = ""
        if role == "tool":
            tool_result = text or flatten_text(rec)
        skill = _detect_skill(rec, tool_calls)
        ts = str(_pick(rec, TS_KEYS, ""))
        ev = SessionEvent(
            index=idx,
            role=role,
            text=text,
            tool_calls=tool_calls,
            tool_result=tool_result,
            skill=skill,
            timestamp=ts,
            raw=rec,
        )
        events.append(ev)
        roles.add(role)
        if skill:
            skills.add(skill)

    all_text_parts: list[str] = []
    all_commands: list[str] = []
    for ev in events:
        tag = ev.role.upper()
        if ev.text:
            all_text_parts.append(f"[{tag}] {ev.text}")
        for tc in ev.tool_calls:
            cmd = f"[TOOL_CALL] {tc['name']} {tc['arguments_text']}".strip()
            all_commands.append(cmd)
            all_text_parts.append(cmd)
        if ev.tool_result:
            all_text_parts.append(f"[TOOL_RESULT] {ev.tool_result}")

    incomplete, reason = _detect_incomplete(events, records)
    return {
        "events": [e.to_dict() for e in events],
        "total_events": len(events),
        "roles": sorted(roles),
        "skills_invoked": sorted(skills),
        "all_text": "\n".join(all_text_parts),
        "all_commands": "\n".join(all_commands),
        "is_incomplete": incomplete,
        "incomplete_reason": reason,
    }


def _detect_incomplete(events: list[SessionEvent], records: list[dict]) -> tuple[bool, str]:
    """Heuristically detect whether a session is incomplete/abruptly cut off."""
    if not events:
        return True, "empty_session"
    roles = [e.role for e in events]
    has_user = "user" in roles
    has_assistant = "assistant" in roles
    if has_user and not has_assistant:
        return True, "user_prompt_without_any_assistant_response"
    # Check the final few events for abrupt termination markers.
    tail_text = "\n".join(e.text for e in events[-3:] if e.text).lower()
    abrupt_markers = ["...[truncated]", "connection reset", "timeout", "aborted", "interrupted",
                      "error:", "exception", "max tokens", "rate limit", "context length"]
    if any(m in tail_text for m in abrupt_markers):
        return True, "abrupt_termination_marker_in_tail"
    # A trailing user message with no following assistant turn.
    if roles and roles[-1] == "user" and has_assistant:
        return True, "trailing_user_message_without_response"
    return False, ""
