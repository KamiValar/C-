#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Merge per-batch ``batch_*_final.xlsx`` files into one consolidated results table.

After the batched pipeline has run
``analyze_batch.py`` -> LLM review -> ``finalize_labels.py`` for every batch,
this script stitches the per-batch final Excel files back into a single
``results_final.xlsx`` whose two key columns are ``tar_md5`` and
``is_malicious`` (plus a few audit columns such as the batch index and the
original ``rule_label`` / ``final_label``).

Duplicate ``tar_md5`` across batches is reported as a warning; the later
batch wins so re-running a batch with corrections cleanly supersedes the
earlier copy.

Usage:
    python merge_batches.py --inputs batch_0_final.xlsx batch_1_final.xlsx \
        --output results_final.xlsx
    # or via a directory glob:
    python merge_batches.py --input-dir . --pattern "batch_*_final.xlsx" \
        --output results_final.xlsx
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


MERGE_HEADERS = [
    "tar_filename",
    "tar_md5",
    "is_malicious",
    "rule_label",
    "batch_index",
    "batch_file",
    "confidence",
    "total_score",
    "top_categories",
    "session_incomplete",
    "missing_layers",
    "final_categories",
    "final_note",
    "parse_errors",
]


def _load_batch_xlsx(path: Path, batch_index: int) -> list[dict]:
    """Read one batch final xlsx and return a list of row dicts keyed by header."""
    from openpyxl import load_workbook

    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    assert ws is not None
    rows_iter = ws.iter_rows(values_only=True)
    try:
        header = next(rows_iter)
    except StopIteration:
        wb.close()
        return []
    header = [str(h) if h is not None else "" for h in header]
    out: list[dict] = []
    for raw_row in rows_iter:
        if raw_row is None or all(v is None for v in raw_row):
            continue
        row = {header[i]: (raw_row[i] if i < len(raw_row) else None) for i in range(len(header))}
        row["batch_index"] = batch_index
        row["batch_file"] = path.name
        out.append(row)
    wb.close()
    return out


def _values_for_output(rec: dict) -> list:
    """Extract the (header-ordered) values for one merged row.

    ``final_categories`` may be a list in the source spreadsheet (if the
    user wrote a custom column) — normalise to a semicolon-joined string.
    """
    label = rec.get("is_malicious")
    if label is None:
        label = rec.get("final_label", rec.get("rule_label", 0))
    label = int(label) if label is not None else 0

    categories = rec.get("final_categories")
    if isinstance(categories, (list, tuple)):
        categories_str = "; ".join(str(c) for c in categories)
    elif categories is None:
        categories_str = ""
    else:
        categories_str = str(categories)

    note = rec.get("review_note") or rec.get("final_note") or ""

    return [
        rec.get("tar_filename", "") or "",
        rec.get("tar_md5") or "",
        label,
        rec.get("rule_label") if rec.get("rule_label") is not None else "",
        rec.get("batch_index") if rec.get("batch_index") is not None else "",
        rec.get("batch_file") or "",
        rec.get("confidence") if rec.get("confidence") is not None else "",
        rec.get("total_score") if rec.get("total_score") is not None else "",
        rec.get("top_categories") or "",
        rec.get("session_incomplete") if rec.get("session_incomplete") is not None else "",
        rec.get("missing_layers") or "",
        categories_str,
        note,
        rec.get("parse_errors") or "",
    ]


def merge(records: list[dict], out_path: Path) -> tuple[int, int, int]:
    """Write merged records to xlsx.

    Returns ``(n_unique, n_duplicates, n_malicious)``.
    """
    wb = Workbook()
    ws = wb.active
    assert ws is not None
    ws.title = "malicious_labels"
    ws.append(MERGE_HEADERS)
    header_fill = PatternFill("solid", fgColor="4472C4")
    header_font = Font(bold=True, color="FFFFFF")
    for col_idx, _ in enumerate(MERGE_HEADERS, start=1):
        cell = ws.cell(row=1, column=col_idx)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")

    # Deduplicate by md5; later batches override earlier ones so re-running
    # a batch with corrections cleanly supersedes stale entries.
    by_md5: dict[str, dict] = {}
    dup_count = 0
    for rec in records:
        md5 = rec.get("tar_md5")
        if not md5:
            continue
        if md5 in by_md5:
            dup_count += 1
            print(
                f"[!] duplicate tar_md5 {md5} in batch {rec['batch_index']} "
                f"({rec.get('batch_file')}); superseding batch "
                f"{by_md5[md5]['batch_index']}",
                file=sys.stderr,
            )
        by_md5[md5] = rec

    n_mal = 0
    for rec in by_md5.values():
        values = _values_for_output(rec)
        n_mal += int(values[2])  # is_malicious column is index 2
        ws.append(values)

    widths = [28, 34, 12, 12, 10, 22, 12, 12, 50, 16, 24, 30, 40, 40]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out_path)
    return len(by_md5), dup_count, n_mal


def _resolve_inputs(args: argparse.Namespace) -> list[Path]:
    if args.inputs:
        files = [Path(p).resolve() for p in args.inputs]
        for f in files:
            if not f.exists():
                raise FileNotFoundError(f"Batch file not found: {f}")
        return files
    if not args.input_dir:
        raise ValueError("Either --inputs or --input-dir must be supplied.")
    base = Path(args.input_dir).resolve()
    if not base.is_dir():
        raise NotADirectoryError(f"--input-dir is not a directory: {base}")
    pattern = args.pattern or "batch_*_final.xlsx"
    files = sorted(base.glob(pattern))
    if not files:
        raise FileNotFoundError(
            f"No files matching '{pattern}' under {base}. "
            "Pass --pattern or list files explicitly with --inputs."
        )
    return files


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Merge per-batch final xlsx files into one consolidated results_final.xlsx."
    )
    ap.add_argument("--inputs", nargs="*", help="Explicit batch_*_final.xlsx paths to merge.")
    ap.add_argument("--input-dir", help="Directory to glob batch files from (use with --pattern).")
    ap.add_argument("--pattern", default="batch_*_final.xlsx", help="Glob pattern under --input-dir.")
    ap.add_argument("--output", "-o", required=True, help="Output xlsx path (e.g. results_final.xlsx).")
    args = ap.parse_args()

    try:
        batch_files = _resolve_inputs(args)
    except (FileNotFoundError, NotADirectoryError, ValueError) as exc:
        print(f"[!] {exc}", file=sys.stderr)
        sys.exit(1)

    out_path = Path(args.output).resolve()
    print(f"[+] Merging {len(batch_files)} batch file(s):")
    for f in batch_files:
        print(f"    - {f.name}")

    all_records: list[dict] = []
    for idx, f in enumerate(batch_files):
        try:
            rows = _load_batch_xlsx(f, idx)
        except Exception as exc:  # noqa: BLE001
            print(f"[!] failed to read {f.name}: {exc}", file=sys.stderr)
            continue
        print(f"    batch {idx}: {len(rows)} rows")
        all_records.extend(rows)

    if not all_records:
        print("[!] No rows to merge.", file=sys.stderr)
        sys.exit(1)

    unique, dup_count, n_mal = merge(all_records, out_path)
    print(f"[+] Merged {unique} unique tar(s) into {out_path.name}.")
    if dup_count:
        print(f"    duplicates superseded: {dup_count}")
    print(f"    malicious: {n_mal}/{unique}")


if __name__ == "__main__":
    main()