#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Finalise labels after LLM review.

Reads the ``_raw.json`` produced by ``analyze_batch.py`` and a decisions
file (JSON mapping ``md5 -> {label, categories, note}``) produced during
LLM review, then regenerates the final Excel with confirmed 0/1 labels.

Decisions are optional: any tar without a decision keeps its rule label.

Usage:
  python finalize_labels.py --raw results_raw.json --decisions decisions.json --output results_final.xlsx
  # Batched pipeline: --raw may point to either the consolidated _raw.json
  # produced by analyze_batch.py, OR the per-sample split directory
  # (<stem>_raw_split/). When a directory is passed, all per-md5 JSON files
  # inside it are read as the source records.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import rule_scorer
from utils import TarRecord


def _load_raw(raw_path: Path) -> list[dict]:
    """Load raw records either from a JSON file or from a split directory."""
    if raw_path.is_dir():
        items: list[dict] = []
        for p in sorted(raw_path.glob("*.json")):
            try:
                obj = json.loads(p.read_text(encoding="utf-8"))
            except Exception as exc:  # noqa: BLE001
                print(f"[!] skipping split file {p.name}: {exc}", file=sys.stderr)
                continue
            if isinstance(obj, dict):
                items.append(obj)
            elif isinstance(obj, list):
                items.extend(obj)
        return items
    return json.loads(raw_path.read_text(encoding="utf-8"))


def _load_decisions(dec_path: Path | None) -> dict:
    if dec_path is None or not dec_path.exists():
        return {}
    return json.loads(dec_path.read_text(encoding="utf-8"))


def _rebuild_records(raw: list[dict]) -> list[TarRecord]:
    records: list[TarRecord] = []
    for item in raw:
        rec = TarRecord(tar_path=Path(item["tar_filename"]))
        rec.tar_md5 = item["tar_md5"]
        rec.rule_label = item["rule_label"]
        rec.needs_review = item["needs_review"]
        rec.final_label = item.get("final_label")
        rec.final_categories = item.get("final_categories", [])
        rec.final_note = item.get("final_note", "")
        rec.session_incomplete = item.get("session_incomplete", False)
        rec.rule_scores = item.get("rule_scores", {})
        rec.rule_evidence = item.get("rule_evidence", {})
        rec.parse_errors = item.get("parse_errors", [])
        rec.missing_layers = item.get("missing_layers", [])
        rec.port_hits = item.get("port_hits", [])
        rec.session_summary = item.get("session_summary", {})
        rec.syslog_summary = item.get("syslog_summary", {})
        rec.sysmon_summary = item.get("sysmon_summary", {})
        rec.pcap_summary = item.get("pcap_summary", {})
        records.append(rec)
    return records


def _apply_decisions(records: list[TarRecord], decisions: dict) -> int:
    applied = 0
    for rec in records:
        dec = decisions.get(rec.tar_md5)
        if not dec:
            continue
        label = dec.get("label")
        if label in (0, 1):
            rec.final_label = int(label)
            rec.final_categories = dec.get("categories", [])
            rec.final_note = dec.get("note", "")
            applied += 1
    return applied


def main() -> None:
    ap = argparse.ArgumentParser(description="Apply LLM review decisions and regenerate the Excel.")
    ap.add_argument("--raw", "-r", required=True, help="Path to the _raw.json from analyze_batch.py.")
    ap.add_argument("--decisions", "-d", default=None, help="JSON mapping md5 -> {label, categories, note}.")
    ap.add_argument("--output", "-o", required=True, help="Output final Excel path.")
    args = ap.parse_args()

    raw = _load_raw(Path(args.raw).resolve())
    decisions = _load_decisions(Path(args.decisions).resolve() if args.decisions else None)
    records = _rebuild_records(raw)
    applied = _apply_decisions(records, decisions)

    # Default final_label to rule_label where no decision was supplied.
    for rec in records:
        if rec.final_label is None:
            rec.final_label = rec.rule_label

    # Import the excel writer from the batch module.
    import analyze_batch as ab
    out_path = Path(args.output).resolve()
    ab._write_excel(records, out_path, label_source="final")

    n_mal = sum(1 for r in records if r.final_label == 1)
    print(f"[+] Applied {applied} LLM decision(s).")
    print(f"[+] Final labels: {n_mal}/{len(records)} malicious.")
    print(f"    Excel: {out_path}")


if __name__ == "__main__":
    main()
