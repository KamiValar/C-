# Port Intelligence Reference

本文档记录开放取证（pcap / sysmon / 会话文本）中常见端口与其对应的可疑语义，
用于 `agent-log-malicious-detector` 的端口先验判定。三处会用到这份知识：

1. **`rule_scorer.py`** 的 12 类 regex：直接把端口→类别的映射编码进 patterns，
   规则初筛即可对命中端口加分。
2. **`parse_ports.py`** 在 `analyze_batch.py` 里被调用，从 pcap flows 与 sysmon
   网络事件中提取 `port_hits`，写入 `raw.json` / `Excel` / `review_queue.md`，
   让 LLM 复核时一眼看出每个 tar 触发了哪些敏感端口。
3. **LLM 语义复核阶段**：当 review_queue 列出 `port_hits` 时，对照本文档判断
   这些端口与已命中的恶意类别是否互相印证（例如 `4444` 命中又叠加
   `5_payload_delivery` → 高置信判 1）。

## 1. 可疑端口 → 类别映射表

> 端口分类不是绝对——同一端口在不同上下文里用途不同（如 `8080` 既可能是合法
> 反向代理，也可能是 RAT 默认控制端口）。复核时**结合上下文**与白名单（§2）
> 判断；不要单凭端口号定罪。

| 端口 | 别名/典型用途 | 对应恶意类别 | 备注 |
|------|--------------|------|------|
| 4444 | Metasploit msfvenom `LPORT` 默认 | `5_payload_delivery` `12_other` | 反向 shell 最经典的 LPORT |
| 1337 |leet speak C2 / BindShell | `5_payload_delivery` `12_other` | 攻击者文化偏好 |
| 4443 | C2 over TLS / WhatsApp TLS 旁路 | `12_other` | 注意白名单：WhatsApp 也用 |
| 31337 | Back Orifice / Elite C2 | `12_other` | 历史 RAT，但仍是高信号 |
| 1234 | 常见 reverse shell/RAT LPORT | `5_payload_delivery` | 同 4444 文化偏好 |
| 12345 | NetBus RAT / Z aidesk backdoor | `12_other` | 历史 RAT |
| 9999 | Nessus / Cobalt Strike 默认 | `12_other` `5_payload_delivery` | Cobalt Strike 常自定义但 9999 是默认 |
| 6660-6669,7000 | IRC（含 IRC C2 / botnet） | `12_other` `9_resource_abuse` | 现代 IRC 已极少正常用 |
| 6667 | IRC 默认 | `12_other` `9_resource_abuse` | botnet C2 重灾区 |
| 6697 | IRC over TLS | `12_other` | 同 6667 |
| 9001 | Tor ORPort 默认 / 各种自管 C2 | `10_evasion` `12_other` | 仅在没有任何 Tor 上下文时可疑 |
| 9030,9050,9051 | Tor SOCKS/Control | `10_evasion` | 自建 Tor 出口规避常见 |
| 9150 | Tor Browser SOCKS | `10_evasion` | 一次性场景，但复现出现仍可疑 |
| 5900 | VNC | `4_privilege_escalation` `12_other` | 远控桌面，结合 sysmon ProcessCreate 看 |
| 3389 | RDP | `4_privilege_escalation` `12_other` | 正常运维也有，但与新增账户/LoginMetrics 同现高度可疑 |
| 4848,4899 | Radmin/TeamViewer 历史后门 | `12_other` | 谨慎核对 |
| 4422,5552,5554 | 反向 shell 文化端口 | `5_payload_delivery` | 反向 shell 文化偏好 |
| 53 | DNS 隧道/DNS C2（正/反常混用） | `3_data_exfiltration` `10_evasion` `12_other` | 白名单端口，但出现 `dig @1.1.1.1 abc.evil.tld TXT` 这种异样要警觉 |
| 53 (异常上下文) | DNS 隧道数据外传 | `3_data_exfiltration` | 看 pcap payload 字节数/TXT 记录长度 |
| 137-139,445 | SMB | `3_data_exfiltration` `12_other` | 外联 SMB（非企业内网）通常可疑 |
| 445 (出向) | SMB 出口 | `3_data_exfiltration` | 存在 `IP gigantic TXT` DNS 记录 + 445 外联 → 高度可疑 |
| 25, 465, 587 | SMTP 外发 | `3_data_exfiltration` `11_social_engineering` | 与钓鱼邮件生成同现更可疑 |
| 110,995 | POP3/POP3S 收件 | `3_data_exfiltration` `11_social_engineering` | 罕见正常 use case |
| 143,993 | IMAP/IMAPS 收件 | `3_data_exfiltration` `11_social_engineering` | 罕见正常 use case |
| 2049 | NFS | `3_data_exfiltration` | 出向外联 NFS 通常是异常 |
| 3306 | MySQL | `3_data_exfiltration` `8_supply_chain` | 出向未授权 MySQL 连接 = 数据外传 |
| 5432 | PostgreSQL | `3_data_exfiltration` | 同 3306 |
| 6379 | Redis（写入攻击常依赖）| `8_supply_chain` `5_payload_delivery` | 公网 Redis + 写 cron 写 SSH key |
| 11211 | Memcached 反射放大 | `9_resource_abuse` | DDoS 反射端口 |
| 5060 | SIP（VoIP 滥用） | `9_resource_abuse` | |
| 161,162 | SNMP | `1_info_recon` `3_data_exfiltration` | 罕见正常 use case |
| 23 | Telnet | `5_payload_delivery` `1_info_recon` | 几乎全为异常 |
| 1723 | PPTP | `10_evasion` `12_other` | 旧 VPN 通常弱安全 |
| 500, 4500 | IPSec/IKE | `10_evasion` | 非企业网络出现可疑 |
| 8080/8443 (异常上下文) | 自建 C2 / RAT 默认 | `12_other` `5_payload_delivery` | 与已知合法 Web 应用同 IP 时排除 |
| 8000 | Django/dev server 异常上下文 | `5_payload_delivery` | 同上 |
| 0 | bind shell / 系统调用异常 | `5_payload_delivery` `12_other` | 端口 0 在 pcap 中正常不应出现 |
| 1080 | SOCKS/Socks5 | `10_evasion` | proxychains 常用 |
| 3128 | Squid proxy | `10_evasion` | 出向代理常见 |
| 4444, 5555, 2323, 7547 | IoT botnet Telnet 掠取 | `1_info_recon` `5_payload_delivery` `9_resource_abuse` | 与 IoT/CPE 关连 |

## 2. 可信端口白名单（避免误报）

以下端口若与管网身份匹配的合法服务对接（例如 8080 命中 ABC.com 公司内网
反向代理），应当忽略此类端口先验加分：

| 端口 | 正常用途 |
|------|----------|
| 80, 443 | HTTP/HTTPS Web |
| 123 | NTP |
| 161/162 | SNMP（企业内网） |
| 53 | DNS（与系统 resolver/IP） |
| 587 / 993 / 995 | SMTP/IMAP/POP3 over TLS（合法邮件提供商 IP） |
| 5353, 5355, 22 | mDNS, LLMNR, SSH（同自治域内） |
| 137-139, 445 | SMB（企业内网） |
| 5222, 5223, 5228 | GCM / XMPP push |
| 9000-something | 大量 dev server，需 7 元组上下文判定 |

> 复核原则：见易端口命中 → 先查 sysmon ProcessCreate 与 pcap dst_ip；
> 若 dst_ip 是该端口业界标准服务/企业内部 deployed，且无其他证据，
> 应判 0 或低置信 1 + 备注说明。

## 3. 复核流程（结合已有的会话/sysmon/pcap 交叉验证）

1. **读取 review_queue 中 `port_hits` 字段**：列出该 tar 命中了哪些可疑端口
   及对应类别标签。例：
   ```
   port_hits:
   - port: 4444 → category: 5_payload_delivery (反 shell)
     sources: pcap(dst=x.x.x.x:4444), sysmon(TcpConnectedPID 1234)
   - port: 6667 → category: 12_other (IRC C2)
     sources: pcap(dst=y.y.y.y:6667)
   ```
2. **逐条对照 §1 映射**：该端口在攻击场景中典型用途是什么？与 review_queue
   里 Top 类别是否互相印证？
3. **排除白名单**：查 §2，若 dst_ip 与端口业界标准 Services一致且无其他证据
   → 视为弱信号或噪声，不单独定罪。
4. **叠加结论**：port_hits 与现有 `rule_evidence` 同类→ 提升置信度
   （可达到 HIGH_CATEGORY 阈值，进入"高置信判 1"）；port_hits 引出未在
   `rule_evidence` 中表现的新类别 → 加入 `categories`（例如 IRC C2 端口
   命中应外加 `9_resource_abuse` 即便会话无明文挖矿话术）。
5. **写 `decisions.json`**：把端口判断纳入 note，例如
   `"note": "pcap 外联 4444 与会话中的 msfvenom LPORT 互相印证"`。

## 4. 实施备注

- `rule_scorer.py` 中端口 regex 统一使用 `:(端口1|端口2|...)\b` 兜底格式，
  兼容 `pcap_all_text`、`sysmon DestinationPort=4444`、session 转 string 中
  `127.0.0.1:4444` 等格式；
- `port_hits` 字段 default 会被 `analyze_batch.py` 的解析阶段写入，所以即便
  `rule_scorer` 不暴露该字段也不会破坏向后兼容；
- 与 `missing_layers` 合用：若 pcap 缺失但 sysmon 命中端口 → 仍可判 1，
  但应在 note 注明证据来源单一；
- 端口判定要 **与上下文叠加**，不独立定罪。